package armasDefensa;

public class TrozoDeMadera implements ArmaDefensa {

    @Override
    public String imagenArmaDefensa() {
        return "/imagenes/Trozo De Madera.jpg";
    }

}
