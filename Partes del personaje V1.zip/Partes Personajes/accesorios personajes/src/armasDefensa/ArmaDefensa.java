package armasDefensa;

public interface ArmaDefensa {
    
    public String imagenArmaDefensa();
    
}
