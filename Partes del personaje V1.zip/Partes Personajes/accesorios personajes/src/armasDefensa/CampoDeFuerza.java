package armasDefensa;

public class CampoDeFuerza implements ArmaDefensa {

    @Override
    public String imagenArmaDefensa() {
        return "/imagenes/Campo De Fuerza.jpg";
    }

}
