package armasDefensa;

public class Escudo implements ArmaDefensa {

    @Override
    public String imagenArmaDefensa() {
        return "/imagenes/Escudo.jpg";
    }

}
