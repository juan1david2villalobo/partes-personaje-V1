package armasDefensa;

public class Armadura implements ArmaDefensa {

    @Override
    public String imagenArmaDefensa() {
        return "/imagenes/Armadura.jpg";
    }

}
