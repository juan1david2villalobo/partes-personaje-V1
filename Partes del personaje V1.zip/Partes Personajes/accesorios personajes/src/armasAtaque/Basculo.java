package armasAtaque;

public class Basculo implements ArmaAtaque {

    @Override
    public String imagenArmaAtaque() {
        return "/imagenes/Basculo.jpg";
    }

}
