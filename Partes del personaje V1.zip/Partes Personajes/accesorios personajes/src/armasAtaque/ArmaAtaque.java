package armasAtaque;

public interface ArmaAtaque {
    
    public String imagenArmaAtaque();
}
