package armasAtaque;

public class Mazo implements ArmaAtaque {

    @Override
    public String imagenArmaAtaque() {
        return "/imagenes/Mazo.jpg";
    }

}
