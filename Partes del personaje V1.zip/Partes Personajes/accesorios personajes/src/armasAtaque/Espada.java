package armasAtaque;

public class Espada implements ArmaAtaque {

    @Override
    public String imagenArmaAtaque() {
        return "/imagenes/Espada.jpg";
    }

}
