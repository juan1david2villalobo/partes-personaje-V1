package armasAtaque;

public class Arco implements ArmaAtaque {

    @Override
    public String imagenArmaAtaque() {
        return "/imagenes/Arco.jpg";
    }

}
