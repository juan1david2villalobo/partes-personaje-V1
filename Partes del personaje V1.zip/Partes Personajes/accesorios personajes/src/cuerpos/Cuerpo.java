package cuerpos;

public interface Cuerpo {
    
    public String imagenCuerpo();
}
