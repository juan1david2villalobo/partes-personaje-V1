package cuerpos;

public class CuerpoElfo implements Cuerpo {

    @Override
    public String imagenCuerpo() {
        return "/imagenes/Elfo.jpg";
    }

}
