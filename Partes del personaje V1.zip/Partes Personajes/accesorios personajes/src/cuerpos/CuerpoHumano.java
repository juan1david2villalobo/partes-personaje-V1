package cuerpos;

public class CuerpoHumano implements Cuerpo {

    @Override
    public String imagenCuerpo() {
        return "/imagenes/Humano.jpg";
    }

}
