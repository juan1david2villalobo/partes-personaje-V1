package cuerpos;

public class CuerpoMago implements Cuerpo {

    @Override
    public String imagenCuerpo() {
        return "/imagenes/Mago.jpg";
    }

}
