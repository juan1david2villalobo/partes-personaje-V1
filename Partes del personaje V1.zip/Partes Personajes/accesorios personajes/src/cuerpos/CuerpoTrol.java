package cuerpos;

public class CuerpoTrol implements Cuerpo {

    @Override
    public String imagenCuerpo() {
        return "/imagenes/Trol.jpg";
    }

}
